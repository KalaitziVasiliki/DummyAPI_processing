
	SELECT *
	FROM public.users;  -- users
	
	SELECT *
	FROM public.posts;  --posts
	
	SELECT *
	FROM public.comments; --comments
	
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- How many new users are added daily?
----------------------------------------

CREATE TABLE DAILY_USER_REGISTRATION AS (
SELECT count(id),TO_DATE(registerdate,'YYYY-MM-DD"T"HH24:MI:SSS"Z"') as registerdate from public.users 
group by TO_DATE(registerdate,'YYYY-MM-DD"T"HH24:MI:SSS"Z"'));


SELECT * FROM DAILY_USER_REGISTRATION

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- What is the average time between registration and first comment?
----------------------------------------

CREATE TABLE DIFF_BTW_REGISTR_AND_COMMENT AS (
SELECT 
	TO_DATE(publishdate,'YYYY-MM-DD"T"HH24:MI:SSS"Z"') -  TO_DATE(registerdate,'YYYY-MM-DD"T"HH24:MI:SSS"Z"')  as time_difference  , B.owner_id 
	from public.users A
inner join 
 public.comments B
on A.id=B.owner_id
)

SELECT * FROM DIFF_BTW_REGISTR_AND_COMMENT

------------------------------------------------------------------------------------------------------------------------
-- Which cities have the most activity, in terms of posts per day?			 		 
----------------------------------------			 
 
 CREATE TABLE MOST_ACTIVE_CITIES_POSTING AS (
  SELECT COUNT(*) as top_cities, A.city
    FROM public.users A 
    INNER JOIN  public.posts B 
	on A.id=B.owner_id 
    GROUP BY A.city
	order by top_cities desc limit 10 )

SELECT * FROM MOST_ACTIVE_CITIES_POSTING

------------------------------------------------------------------------------------------------------------------------
-- Which tags are most frequently encountered, across user posts?
----------------------------------------

CREATE TABLE MOST_USED_TAGS_POSTING AS 
(
select (T1.c1+ T1.c2 + T2.c3) as tag_frequency, T1.tag1 as tags 
from
((select tag1, count(*) as C1 from public.posts  group by tag1 order by count(*) desc) A
inner join
(select tag2, count(*) as C2 from public.posts  group by tag2 order by count(*) desc) B
on A.tag1=B.tag2) T1
inner join
(select tag3, count(*) as C3 from public.posts group by tag3 order by count(*) desc) T2
on T1.tag1=T2.tag3
order by tag_frequency desc
)


SELECT * FROM MOST_USED_TAGS_POSTING