#!/bin/bash

#This the main script that reads from API and stores Datasets in Postgres

#Parameters
C:\Users\kalai\Downloads\learnworlds\logs
C:\Users\kalai\Downloads\learnworlds\scripts
log_file=C:/Users/kalai/Downloads/learnworlds/logs/fa_log_$(date +%Y_%m_%d).log
EX1=/C:/Users/kalai/Downloads/learnworlds/src/Exercise_1.py
EX2=/C:/Users/kalai/Downloads/learnworlds/src/Exercise_2.py
EX3=/C:/Users/kalai/Downloads/learnworlds/src/Exercise_3.py


local_datapath=
hdfs_datapath=

#Starting writting in log file
echo -e "Starting process at $(date)" 2>&1 | tee -a ${log_file}

#Run python codes 

echo -e "\nStarting..." 2>&1 | tee -a ${log_file}
cd /C:/Users/kalai/Downloads/learnworlds/src/
python Exercise_1.py 
echo -e "\nRunning Python script of Exercise 1: Data Ingestion and Validation" 2>&1 | tee -a ${log_file}

python Exercise_2.py 
echo -e "\nRunning Python script of Exercise 2: Data Loading" 2>&1 | tee -a ${log_file}

python Exercise_3.py 
echo -e "\nRunning Python script of Exercise 3: Data Transformation" 2>&1 | tee -a ${log_file}


#Clear old logs Retention is on 10 days
#echo -e "\nCleaning old log files\n" 2>&1 | tee -a ${log_file}
